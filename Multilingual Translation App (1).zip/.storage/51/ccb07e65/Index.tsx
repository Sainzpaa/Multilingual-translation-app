import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Type, Languages, Globe, Users, ArrowRight } from "lucide-react";
import { VoiceTranslationCard } from "@/components/VoiceTranslationCard";
import { TranslationCard } from "@/components/TranslationCard";
import { TranslationHistory } from "@/components/TranslationHistory";

interface TranslationEntry {
  id: string;
  sourceText: string;
  translatedText: string;
  fromLang: string;
  toLang: string;
  timestamp: Date;
}

export default function Index() {
  const [mode, setMode] = useState<"voice" | "text" | null>(null);
  const [fromLang, setFromLang] = useState("en");
  const [toLang, setToLang] = useState("es");
  const [history, setHistory] = useState<TranslationEntry[]>([]);

  const handleTranslation = (sourceText: string, translatedText: string, fromLang: string, toLang: string) => {
    const newEntry: TranslationEntry = {
      id: Date.now().toString(),
      sourceText,
      translatedText,
      fromLang,
      toLang,
      timestamp: new Date(),
    };
    setHistory(prev => [newEntry, ...prev]);
  };

  const handleSwapLanguages = () => {
    setFromLang(toLang);
    setToLang(fromLang);
  };

  if (mode === "voice") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        {/* Header */}
        <div className="sticky top-0 bg-white/80 backdrop-blur-sm border-b z-10">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={() => setMode(null)}
                className="text-sm"
              >
                ← Back
              </Button>
              <h1 className="text-lg font-semibold">Voice Translation</h1>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMode("text")}
              >
                Text Mode
              </Button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 py-6 space-y-6">
          <VoiceTranslationCard
            id="voice-card"
            fromLang={fromLang}
            toLang={toLang}
            onFromLangChange={setFromLang}
            onToLangChange={setToLang}
            onSwap={handleSwapLanguages}
            onTranslation={handleTranslation}
          />

          {/* Compact Info Footer */}
          <div className="bg-blue-50 rounded-lg p-4 mt-8">
            <div className="flex items-center gap-3 text-sm text-blue-700">
              <Globe className="h-5 w-5 flex-shrink-0" />
              <div>
                <p className="font-medium">Connecting the world through language</p>
                <p className="text-xs text-blue-600 mt-1">Supporting 25+ languages from developing countries</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (mode === "text") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        {/* Header */}
        <div className="sticky top-0 bg-white/80 backdrop-blur-sm border-b z-10">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={() => setMode(null)}
                className="text-sm"
              >
                ← Back
              </Button>
              <h1 className="text-lg font-semibold">Text Translation</h1>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMode("voice")}
              >
                Voice Mode
              </Button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 py-6 space-y-6">
          <TranslationCard
            id="text-card"
            fromLang={fromLang}
            toLang={toLang}
            onFromLangChange={setFromLang}
            onToLangChange={setToLang}
            onSwap={handleSwapLanguages}
            onTranslation={handleTranslation}
          />

          {history.length > 0 && (
            <TranslationHistory 
              history={history} 
              onClearHistory={() => setHistory([])} 
            />
          )}

          {/* Compact Info Footer */}
          <div className="bg-blue-50 rounded-lg p-4 mt-8">
            <div className="flex items-center gap-3 text-sm text-blue-700">
              <Globe className="h-5 w-5 flex-shrink-0" />
              <div>
                <p className="font-medium">Connecting the world through language</p>
                <p className="text-xs text-blue-600 mt-1">Supporting 25+ languages from developing countries</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-8 sm:py-12">
        <div className="text-center space-y-6 max-w-3xl mx-auto">
          <div className="space-y-4">
            <Badge variant="secondary" className="px-3 py-1">
              <Languages className="h-4 w-4 mr-2" />
              25+ Languages Supported
            </Badge>
            <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Voice Translation
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Break language barriers with real-time voice and text translation focusing on developing countries
            </p>
          </div>

          {/* Mode Selection Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mt-8 sm:mt-12">
            <Button
              onClick={() => setMode("voice")}
              className="h-auto p-4 sm:p-6 flex flex-col items-center gap-3 sm:gap-4 bg-blue-500 hover:bg-blue-600 text-white"
              size="lg"
            >
              <MessageCircle className="h-8 w-8 sm:h-12 sm:w-12" />
              <div className="text-center">
                <h3 className="text-lg sm:text-xl font-semibold">Voice Mode</h3>
                <p className="text-xs sm:text-sm opacity-90 mt-1">
                  Speak naturally and get instant translations
                </p>
              </div>
              <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5" />
            </Button>

            <Button
              onClick={() => setMode("text")}
              variant="outline"
              className="h-auto p-4 sm:p-6 flex flex-col items-center gap-3 sm:gap-4 border-2 hover:bg-gray-50"
              size="lg"
            >
              <Type className="h-8 w-8 sm:h-12 sm:w-12" />
              <div className="text-center">
                <h3 className="text-lg sm:text-xl font-semibold">Text Mode</h3>
                <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                  Type or paste text for translation
                </p>
              </div>
              <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5" />
            </Button>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12 sm:mt-16">
            <div className="text-center">
              <div className="bg-green-100 rounded-full p-3 w-12 h-12 mx-auto mb-3">
                <Users className="h-6 w-6 text-green-600" />
              </div>
              <h4 className="font-semibold mb-2">Real-time Conversation</h4>
              <p className="text-sm text-muted-foreground">
                Have natural conversations across language barriers
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 rounded-full p-3 w-12 h-12 mx-auto mb-3">
                <Globe className="h-6 w-6 text-blue-600" />
              </div>
              <h4 className="font-semibold mb-2">Global Reach</h4>
              <p className="text-sm text-muted-foreground">
                Focus on languages from developing countries worldwide
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-purple-100 rounded-full p-3 w-12 h-12 mx-auto mb-3">
                <MessageCircle className="h-6 w-6 text-purple-600" />
              </div>
              <h4 className="font-semibold mb-2">Speech Bubbles</h4>
              <p className="text-sm text-muted-foreground">
                Chat-style interface with audio playback
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}